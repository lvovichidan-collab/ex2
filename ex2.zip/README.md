The docs: https://docs.google.com/document/d/1BFdbF1hX_0scbRBuHutbZe7ZNmMLdyckUDQTWmsXHkI/edit?tab=t.0
